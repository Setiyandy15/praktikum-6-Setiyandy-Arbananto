<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\MahasiswaController;
use App\Http\Controllers\IsiBukuController;
use App\Http\Controllers\IsianFormController;
use App\Http\Controllers\BarangController;
use App\Http\Controllers\BukuController;
use App\Http\Controllers\GuruController;
use App\Http\Controllers\MenuController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

route::get('/menu', [MenuController::class, 'menu']);
route::post('/menu/proses', [MenuController::class, 'menu_proses']);


route::get('/formulir', [GuruController::class, 'formulir']);
route::post('/formulir/proses', [GuruController::class, 'formulir_proses']);

Route::get('/', function () {
    return view('welcome');
});

route::get('/data_mahasiswa', function() {
    return view('datamahasiswa');
});

route::get('/menumasakan', function() {
    return view('menumasakan');
});

route::get('/daftar_mahasiswa',
    [MahasiswaController::class, 'index']);

//routing data buku perpustakaan
route::get('/form_buku', function() {
    return view('form-buku');
});

route::get('/tabel_buku', function() {
    return view('buku-perpus');
});

route::get('/formbuku',
    [IsianFormController::class, 'index']);

route::get('/bukuperpus',
    [IsiBukuController::class, 'index']);

//routing data barang
route::get('/databarang', function() {
    return view('databarang');
});
    
route::get('/databarang',
    [BarangController::class, 'data_barang']);