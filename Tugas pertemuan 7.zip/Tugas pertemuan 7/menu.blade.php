<DOCTYPE html>
<html>
    <head>
        <title>Daftar Menu</title>
    </head>
    <body>
        <table>
        <tr>
            <th>Makanan</th>
            <th>Minuman</th>
        </tr>
        <tr>
            <td>1. Nasi & Ikan Nila Bakar</td>
            <td>1. Es Teh</td>
        </tr>
        <tr>
            <td>2. Nasi & Ikan Lele Bakar</td>
            <td>2. Es Jeruk</td>
        </tr>
        <tr>
            <td>3. Nasi & Ayam Goreng</td>
            <td>3. Jeruk Panas</td>
        </tr>
        <tr>
            <td>4. Nasi & Bebek Goreng</td>
            <td>4. Teh Panas</td>
        </tr>
        </table>

        <p>Silahkan Pilih Menu</p>
        <form action="/menu/proses" method="POST">
        @csrf
        <br>
        <label>Makanan</label>
        <br>
        <input type="text" name="makan">
        <br>
        <label>Minuman</label>
        <br>
        <input type="text" name="minum">
        <br>
        <input type="submit" value="Pesan">
    </form>
    </body>
</html>